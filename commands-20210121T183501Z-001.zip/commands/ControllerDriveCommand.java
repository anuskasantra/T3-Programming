package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.CommandBase;
import frc.robot.subsystems.DriveTrainSub;

/**
 * @author Daniel Pearson
 * @version 1/9/2020
 */
public class ControllerDriveCommand extends CommandBase {
  //initiates objects
  private static DriveTrainSub drive;
  private static float leftSpeed;
  private static float rightSpeed;





public ControllerDriveCommand(DriveTrainSub subsystem, double leftSupplier, double rightSupplier) {
    drive = subsystem;
    leftSpeed = (float) leftSupplier;
    rightSpeed = (float) rightSupplier;
    addRequirements(drive);
  }

  @Override
  public void initialize() {
  }

  @Override
  public void execute() {
    drive.arcadeDrive(leftSpeed, rightSpeed);
  }

  @Override
  public void end(boolean interrupted) {
    drive.manualDrive(0, 0);
  }

  @Override
  public boolean isFinished() {
    return false;
  }
}